@echo off
cd /d "%~dp0"
echo Creating Python environment...
python -m venv .venv || (echo Python not found. Install it from python.org first. & pause & exit /b 1)
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
if not exist .env copy .env.example .env
echo.
echo Done. Now open .env in Notepad and paste your Claude API key.
pause
