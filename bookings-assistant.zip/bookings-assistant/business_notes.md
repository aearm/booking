# Business notes for Claude

Write plain-English hints below the line. Claude reads them with every question,
so good notes = better answers. (Anything inside the grey example block is ignored.)

<!--
Examples - copy the style, not the content:
- "Revenue" means the measure [Gross Revenue] unless I say "net".
- "Bookings" means [Booking Count]; cancelled bookings are already excluded.
- Use 'Date'[Booking Date] for when a booking was made and 'Date'[Travel Date] for when travel happens.
- Our financial year starts in April.
- "Europe" means the value "EMEA" in 'Destination'[Region].
-->

---

