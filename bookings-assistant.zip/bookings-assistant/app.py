"""Ask questions about the bookings model in plain English.

Run:  streamlit run app.py   (or double-click run_app.bat)
"""
import re
from datetime import date

import streamlit as st

import config
import llm
import ssas
import storage
from charts import build_figure

st.set_page_config(page_title="Bookings Assistant", page_icon="📊", layout="wide")


# ---------------------------------------------------------------- helpers --

def load_text(path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""


def answer(question: str, context: list[dict]) -> dict:
    """Question -> DAX -> data -> chart. Retries once if the DAX fails."""
    schema = load_text(config.SCHEMA_FILE)
    notes = re.sub(r"<!--.*?-->", "", load_text(config.NOTES_FILE), flags=re.DOTALL)
    today = date.today().isoformat()
    turn = {"question": question}

    with st.status("Working on it...", expanded=False) as status:
        status.write("Writing the query")
        result = llm.question_to_dax(question, schema, notes, today, context)
        try:
            status.write("Pulling data from the model")
            df = ssas.run_query(result["dax"], max_rows=config.MAX_ROWS)
        except Exception as first_error:
            status.write("Query failed, asking Claude to fix it")
            result = llm.question_to_dax(question, schema, notes, today, context,
                                         failed_dax=result["dax"], error=str(first_error)[:1500])
            df = ssas.run_query(result["dax"], max_rows=config.MAX_ROWS)

        df = ssas.clean_column_names(df)
        turn.update(dax=result["dax"], explanation=result.get("explanation", ""), df=df)

        if df.empty:
            turn["spec"] = {"chart_type": "table", "title": "No results",
                            "summary": "The query ran but returned no rows. Try widening the filters or dates."}
        else:
            status.write("Choosing a chart")
            turn["spec"] = llm.describe_result(question, df)
        turn["file"] = storage.save_result(question, turn["dax"], df, turn["spec"])
        status.update(label="Done", state="complete")
    return turn


def show_turn(i: int, turn: dict) -> None:
    with st.chat_message("user"):
        st.write(turn["question"])
    with st.chat_message("assistant"):
        if "error" in turn:
            st.error(turn["error"])
            return
        spec, df = turn["spec"], turn["df"]
        st.markdown(spec.get("summary", ""))
        fig = build_figure(df, spec)
        if fig is not None:
            st.plotly_chart(fig, key=f"chart_{i}")
        else:
            st.dataframe(df, hide_index=True)
        if turn.get("explanation"):
            st.caption(turn["explanation"])
        with st.expander(f"Data ({len(df)} rows)"):
            st.dataframe(df, hide_index=True)
            st.download_button("Download CSV", df.to_csv(index=False).encode("utf-8"),
                               file_name="result.csv", mime="text/csv", key=f"dl_{i}")
        with st.expander("DAX query"):
            st.code(turn["dax"], language="sql")
            if st.button("Save this query for scheduled pulls", key=f"save_{i}"):
                name = storage.save_query_for_schedule(spec.get("title") or turn["question"], turn["dax"])
                st.success(f"Saved as queries/{name}. pull.py will refresh it on schedule.")


# ---------------------------------------------------------------- sidebar --

with st.sidebar:
    st.header("📊 Bookings Assistant")
    st.caption(f"Model: **{config.SSAS_DATABASE}**  \nServer: `{config.SSAS_SERVER}`")

    if config.SCHEMA_FILE.exists():
        st.success("Model structure loaded")
    else:
        st.warning("Model structure not read yet")
    if st.button("Refresh model structure"):
        with st.spinner("Reading tables and measures..."):
            try:
                text, n_cols, n_meas = ssas.build_schema_text()
                config.SCHEMA_FILE.write_text(text, encoding="utf-8")
                st.success(f"Found {n_meas} measures and {n_cols} columns.")
            except Exception as exc:
                st.error(f"Could not read the model: {exc}")

    if config.SCHEMA_FILE.exists():
        with st.expander("What Claude can see"):
            st.markdown(load_text(config.SCHEMA_FILE))

    if st.button("Clear conversation"):
        st.session_state.turns = []

    history = storage.load_history()
    if history:
        st.subheader("Recent questions")
        for j, h in enumerate(history):
            if st.button(h["question"][:60], key=f"hist_{j}"):
                st.session_state.pending = h["question"]


# ---------------------------------------------------------------- main --

st.title("Ask about bookings")
st.caption("Ask in plain English, e.g. *Bookings by month this year*, "
           "*Top 10 destinations by revenue in 2026*, *Compare this month with the same month last year*.")

if "turns" not in st.session_state:
    st.session_state.turns = []

for i, t in enumerate(st.session_state.turns):
    show_turn(i, t)

typed = st.chat_input("Ask a question about the bookings data")
question = typed or st.session_state.pop("pending", None)

if question:
    if not config.SCHEMA_FILE.exists():
        st.error("Click **Refresh model structure** in the sidebar first (or run build_schema.py).")
    else:
        context = [t for t in st.session_state.turns if "dax" in t]
        try:
            turn = answer(question, context)
        except Exception as exc:
            turn = {"question": question, "error": f"Sorry, that didn't work: {exc}"}
        st.session_state.turns.append(turn)
        show_turn(len(st.session_state.turns) - 1, turn)
