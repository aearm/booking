"""Step 1: test the connection and save the model's structure to schema.md.

Run:  python build_schema.py
Re-run whenever measures or tables are added to the model.
"""
import sys

import config
import ssas


def main() -> int:
    print(f"Connecting to {config.SSAS_SERVER} / {config.SSAS_DATABASE} ...")
    try:
        text, n_cols, n_meas = ssas.build_schema_text()
    except Exception as exc:  # show a friendly message instead of a long traceback
        print("\nCould not read the model.")
        print(f"Reason: {exc}")
        print("\nCheck: ADOMD.NET is installed, you are on the company network/VPN, "
              "and your Windows login can open this model in Excel or Power BI.")
        return 1

    config.SCHEMA_FILE.write_text(text, encoding="utf-8")
    print(f"Connected. Found {n_meas} measures and {n_cols} columns.")
    print(f"Saved to {config.SCHEMA_FILE.name}. Add notes for Claude in {config.NOTES_FILE.name}.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
