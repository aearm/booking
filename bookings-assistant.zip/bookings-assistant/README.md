# Bookings Assistant

Ask questions about the **GlobalTravelEngine - Bookings** model in plain English and get a
chart, a short written answer, and the data.

```
Your question  ->  Claude writes a DAX query  ->  runs against bi.gte.travel:1564
               ->  results saved as CSV       ->  Claude picks a chart + writes the answer
```

Nothing is ever written to the model: DAX queries are read-only.

---

## One-time setup (about 15 minutes)

**Before you start:** check with IT that it's OK to send booking query results to the
Claude API. The model's table/measure names and the query results are sent to Claude.

1. **Install Python 3.12** from https://www.python.org/downloads/windows/
   - On the first installer screen, tick **"Add python.exe to PATH"**.

2. **Install ADOMD.NET** (lets Python talk to Analysis Services, like Excel does)
   - Go to https://learn.microsoft.com/analysis-services/client-libraries
   - Under **Windows Installer (MSI)**, click the **ADOMD** download link and run the .msi.
   - If that download no longer works or you can't install software, skip it: after
     step 5, run `python get_adomd.py` instead. It downloads ADOMD.NET from NuGet
     into this folder (no admin rights needed).

3. **Get a Claude API key** at https://platform.claude.com/settings/keys (add billing, then create a key).

4. **Unzip this folder** somewhere simple, e.g. `C:\BookingsAssistant`.

5. **Double-click `setup.bat`.** It creates a Python environment and installs everything.

6. **Open `.env` in Notepad**:
   - paste your API key after `ANTHROPIC_API_KEY=`
   - if you log in to the server with a username and password, put the username after
     `SSAS_USERNAME=` exactly as you type it in Excel (often `DOMAIN\username`).
     Leave it blank if Excel uses your Windows login without asking.
   - Save.

7. **Save your password** (only if you set `SSAS_USERNAME`). Open Command Prompt in the folder:
   ```
   .venv\Scripts\activate
   python set_password.py
   ```
   Type the password (nothing shows as you type) and press Enter. It's stored in Windows
   Credential Manager, not in any file. Run this again whenever your password changes.

8. **Test the connection.** In the same Command Prompt:
   ```
   python build_schema.py
   ```
   You should see: `Connected. Found N measures and M columns.`
   This saves `schema.md`, the list of tables and measures Claude is allowed to use.

9. **Add business notes (recommended).** Open `business_notes.md` and write short hints,
   e.g. which measure "revenue" means, or which date column to use. This makes the
   biggest difference to answer quality.

## Daily use

Double-click **`run_app.bat`**. Your browser opens at http://localhost:8501.
Type a question, e.g.:
- *Bookings by month for 2026*
- *Top 10 destinations by revenue this year*
- *Compare this month with the same month last year by channel*
- Follow-ups work: *now only for Spain*, *show it as a table*

Under each answer you can open the **data** (and download it as CSV) and the **DAX query**
(so you can check it, or paste it into DAX Studio / Power BI).

Every answer is saved automatically:
- `data/results/` - one CSV per question
- `data/history.jsonl` - question, DAX, and summary log (also shown in the sidebar)

## Scheduled pulls (optional)

1. In the app, under an answer, open **DAX query** and click
   **Save this query for scheduled pulls**. It's saved in `queries/`.
2. Open **Task Scheduler** > **Create Basic Task** > choose a time (e.g. daily 07:00) >
   **Start a program** > browse to `run_pull.bat`.
3. Fresh data lands in `data/snapshots/` (latest copy + a dated copy each run).
   Results and errors are logged in `data/pull_log.txt`.

You can point Excel or Power BI at those CSVs, or ask the app new questions any time.

## Troubleshooting

| Problem | Fix |
|---|---|
| `ADOMD.NET was not found` | Do step 2, or run `python get_adomd.py`. If installed somewhere unusual, set `ADOMD_PATH` in `.env` to the folder containing `Microsoft.AnalysisServices.AdomdClient.dll`. |
| Connection refused / timeout | Connect to the company network or VPN. Check Excel can still refresh from the same server. |
| Access denied / login failed | Check `SSAS_USERNAME` matches what you type in Excel (including the `DOMAIN\` part), then re-run `python set_password.py`. Your account needs read permission on the model. |
| `No password saved for ...` | Run `python set_password.py`. |
| `pythonnet` / `clr` errors | Use Python 3.12 (64-bit). Then delete the `.venv` folder and run `setup.bat` again. |
| Wrong measure or column picked | Add a line to `business_notes.md` explaining what you meant. |
| Model changed (new measures) | Click **Refresh model structure** in the sidebar. |
| Answers too slow / costly | Keep `claude-sonnet-5-5`; for simple questions you can try `claude-haiku-4-5-20251001` in `.env`. |

## Files

| File | What it does |
|---|---|
| `app.py` | The web app (question box, charts, history) |
| `llm.py` | Prompts Claude: question to DAX, result to chart + summary |
| `ssas.py` | Connects to Analysis Services, runs queries, reads the model structure |
| `charts.py` | Draws the chart Claude chose (Plotly) |
| `storage.py` | Saves results and history |
| `build_schema.py` | Tests the connection and writes `schema.md` |
| `pull.py` | Re-runs saved queries for scheduled refreshes |
| `get_adomd.py` | Backup way to get ADOMD.NET without the installer |
| `set_password.py` | Saves your server password securely in Windows Credential Manager |
| `.env` | Your settings and API key (keep private, don't share or email it) |
