"""Tries the common login settings for Analysis Services and tells you which one works.

Run:  python test_connection.py
If one works, it offers to save that setting to .env for you.
"""
import re
import sys

import config
import ssas

TEST_QUERY = "SELECT [CATALOG_NAME] FROM $SYSTEM.DBSCHEMA_CATALOGS"

# (description, extra connection-string settings)
VARIANTS = [
    ("Default settings", ""),
    ("Force NTLM login", "SSPI=NTLM;"),
    ("Force Kerberos login", "SSPI=Kerberos;"),
    ("NTLM + basic protection level", "SSPI=NTLM;Protection Level=Connect;"),
    ("Encrypted connection", "Protection Level=Pkt Privacy;"),
    ("NTLM + encrypted connection", "SSPI=NTLM;Protection Level=Pkt Privacy;"),
]


def short_error(exc: Exception) -> str:
    first = str(exc).strip().splitlines()[0] if str(exc).strip() else repr(exc)
    return first[:160]


def try_variant(extra: str, use_login: bool) -> str | None:
    """Returns None on success, or a short error message."""
    saved_user, saved_extra = config.SSAS_USERNAME, config.SSAS_CONNECTION_EXTRA
    try:
        if not use_login:
            config.SSAS_USERNAME = ""
        config.SSAS_CONNECTION_EXTRA = extra
        ssas.run_query(TEST_QUERY, max_rows=5, conn_str=ssas.connection_string())
        return None
    except Exception as exc:
        return short_error(exc)
    finally:
        config.SSAS_USERNAME, config.SSAS_CONNECTION_EXTRA = saved_user, saved_extra


def save_to_env(extra: str, clear_username: bool) -> None:
    env = config.BASE_DIR / ".env"
    text = env.read_text(encoding="utf-8") if env.exists() else ""
    for key, value in (("SSAS_CONNECTION_EXTRA", extra),) + ((("SSAS_USERNAME", ""),) if clear_username else ()):
        line = f"{key}={value}"
        if re.search(rf"^{key}=.*$", text, flags=re.MULTILINE):
            text = re.sub(rf"^{key}=.*$", lambda _: line, text, flags=re.MULTILINE)
        else:
            text += f"\n{line}\n"
    env.write_text(text, encoding="utf-8")


def main() -> int:
    print(f"Server:   {config.SSAS_SERVER}\nDatabase: {config.SSAS_DATABASE}")
    print(f"Username: {config.SSAS_USERNAME or '(none - Windows login)'}\n")

    plans = []
    if config.SSAS_USERNAME:
        plans += [(f"{name} [username + password]", extra, True) for name, extra in VARIANTS]
    plans += [(f"{name} [your Windows login]", extra, False) for name, extra in VARIANTS[:2]]

    for name, extra, use_login in plans:
        print(f"Trying: {name} ... ", end="", flush=True)
        error = try_variant(extra, use_login)
        if error is None:
            print("WORKS")
            print(f"\nUse these settings in .env:\n  SSAS_CONNECTION_EXTRA={extra}")
            if config.SSAS_USERNAME and not use_login:
                print("  SSAS_USERNAME=   (leave blank: your Windows login works)")
            answer = input("\nSave this to .env now? (y/n): ").strip().lower()
            if answer == "y":
                save_to_env(extra, clear_username=bool(config.SSAS_USERNAME) and not use_login)
                print("Saved. Next: python build_schema.py")
            return 0
        print(f"failed: {error}")

    print("\nNone worked. Send the output above (it contains no password) to get help.")
    print("Also check in Power BI Desktop: File > Options and settings > Data source settings >")
    print("select bi.gte.travel > Edit Permissions > Credentials 'Edit', and note which tab")
    print("(Windows / Database) and exact username format it uses.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
